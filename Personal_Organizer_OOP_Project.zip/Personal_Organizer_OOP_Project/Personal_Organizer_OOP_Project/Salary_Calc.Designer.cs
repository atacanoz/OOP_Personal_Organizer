﻿namespace Personal_Organizer_OOP_Project
{
    partial class Salary_Calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.Labelc5 = new System.Windows.Forms.Label();
            this.btn_quit = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelBaz = new System.Windows.Forms.Label();
            this.labelKatsayi = new System.Windows.Forms.Label();
            this.labelUcret = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.numericDeneyim = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioIngYok = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.numericDiger = new System.Windows.Forms.NumericUpDown();
            this.radioMez = new System.Windows.Forms.RadioButton();
            this.radioBelgIng = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUni = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.numeric718 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.checkEsCalısmıyor = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numeric06 = new System.Windows.Forms.NumericUpDown();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.buttonDown = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_quit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDeneyim)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericDiger)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric718)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric06)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel2.Controls.Add(this.Labelc5);
            this.panel2.Controls.Add(this.btn_quit);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1226, 55);
            this.panel2.TabIndex = 9;
            // 
            // Labelc5
            // 
            this.Labelc5.AutoSize = true;
            this.Labelc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Labelc5.ForeColor = System.Drawing.Color.White;
            this.Labelc5.Location = new System.Drawing.Point(15, 11);
            this.Labelc5.Name = "Labelc5";
            this.Labelc5.Size = new System.Drawing.Size(194, 29);
            this.Labelc5.TabIndex = 15;
            this.Labelc5.Text = "Salary Calculator";
            // 
            // btn_quit
            // 
            this.btn_quit.Image = global::Personal_Organizer_OOP_Project.Properties.Resources.bb;
            this.btn_quit.InitialImage = global::Personal_Organizer_OOP_Project.Properties.Resources.bb;
            this.btn_quit.Location = new System.Drawing.Point(1199, 11);
            this.btn_quit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_quit.Name = "btn_quit";
            this.btn_quit.Size = new System.Drawing.Size(51, 33);
            this.btn_quit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btn_quit.TabIndex = 13;
            this.btn_quit.TabStop = false;
            this.btn_quit.Click += new System.EventHandler(this.btn_quit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 575);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1226, 75);
            this.panel1.TabIndex = 10;
            // 
            // labelBaz
            // 
            this.labelBaz.AutoSize = true;
            this.labelBaz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelBaz.Location = new System.Drawing.Point(17, 78);
            this.labelBaz.Name = "labelBaz";
            this.labelBaz.Size = new System.Drawing.Size(365, 25);
            this.labelBaz.TabIndex = 11;
            this.labelBaz.Text = "Computer engineer base wage= 26829 tl";
            // 
            // labelKatsayi
            // 
            this.labelKatsayi.AutoSize = true;
            this.labelKatsayi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelKatsayi.Location = new System.Drawing.Point(17, 113);
            this.labelKatsayi.Name = "labelKatsayi";
            this.labelKatsayi.Size = new System.Drawing.Size(185, 25);
            this.labelKatsayi.TabIndex = 12;
            this.labelKatsayi.Text = "Wage coefficient= 1";
            // 
            // labelUcret
            // 
            this.labelUcret.AutoSize = true;
            this.labelUcret.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelUcret.Location = new System.Drawing.Point(745, 78);
            this.labelUcret.Name = "labelUcret";
            this.labelUcret.Size = new System.Drawing.Size(0, 36);
            this.labelUcret.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(27, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "Province";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(241, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 20);
            this.label5.TabIndex = 17;
            this.label5.Text = "Experience (years)";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Master\'s Degree in Related Field",
            "PhD in Related Field",
            "Associate Professorship in Related Field",
            "Master\'s Degree in Unrelated Field",
            "PhD/Associate Professorship in Unrelated Field"});
            this.checkedListBox1.Location = new System.Drawing.Point(802, 281);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(445, 142);
            this.checkedListBox1.TabIndex = 2;
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(798, 258);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Education";
            // 
            // numericDeneyim
            // 
            this.numericDeneyim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericDeneyim.Location = new System.Drawing.Point(245, 200);
            this.numericDeneyim.Name = "numericDeneyim";
            this.numericDeneyim.Size = new System.Drawing.Size(146, 28);
            this.numericDeneyim.TabIndex = 1;
            this.numericDeneyim.ValueChanged += new System.EventHandler(this.numericDeneyim_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.Controls.Add(this.radioIngYok);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.numericDiger);
            this.groupBox2.Controls.Add(this.radioMez);
            this.groupBox2.Controls.Add(this.radioBelgIng);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(391, 258);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(362, 201);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Languages";
            // 
            // radioIngYok
            // 
            this.radioIngYok.AutoSize = true;
            this.radioIngYok.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioIngYok.Location = new System.Drawing.Point(6, 29);
            this.radioIngYok.Name = "radioIngYok";
            this.radioIngYok.Size = new System.Drawing.Size(118, 26);
            this.radioIngYok.TabIndex = 0;
            this.radioIngYok.TabStop = true;
            this.radioIngYok.Text = "No English";
            this.radioIngYok.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(6, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(350, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Other Certified Foreign Languages";
            // 
            // numericDiger
            // 
            this.numericDiger.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericDiger.Location = new System.Drawing.Point(6, 147);
            this.numericDiger.Name = "numericDiger";
            this.numericDiger.Size = new System.Drawing.Size(120, 28);
            this.numericDiger.TabIndex = 3;
            this.numericDiger.ValueChanged += new System.EventHandler(this.numericDiger_ValueChanged);
            // 
            // radioMez
            // 
            this.radioMez.AutoSize = true;
            this.radioMez.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioMez.Location = new System.Drawing.Point(6, 91);
            this.radioMez.Name = "radioMez";
            this.radioMez.Size = new System.Drawing.Size(309, 26);
            this.radioMez.TabIndex = 2;
            this.radioMez.TabStop = true;
            this.radioMez.Text = "Graduation from an English School";
            this.radioMez.UseVisualStyleBackColor = true;
            this.radioMez.CheckedChanged += new System.EventHandler(this.radioMez_CheckedChanged);
            // 
            // radioBelgIng
            // 
            this.radioBelgIng.AutoSize = true;
            this.radioBelgIng.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBelgIng.Location = new System.Drawing.Point(6, 60);
            this.radioBelgIng.Name = "radioBelgIng";
            this.radioBelgIng.Size = new System.Drawing.Size(255, 26);
            this.radioBelgIng.TabIndex = 1;
            this.radioBelgIng.TabStop = true;
            this.radioBelgIng.Text = "Certified English Proficiency";
            this.radioBelgIng.UseVisualStyleBackColor = true;
            this.radioBelgIng.CheckedChanged += new System.EventHandler(this.radioBelgIng_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "No Managerial Role",
            "Team Leader",
            "Group Manager",
            "Technical Manager",
            "Software Architect",
            "Project Manager",
            "Director",
            "Projects Manager",
            "CTO",
            "General Manager",
            "IT Officer (5 or fewer staff)",
            "IT Manager (5 or fewer staff)",
            "IT Officer (more than 5 staff)",
            "IT Manager (more than 5 staff)"});
            this.comboBox1.Location = new System.Drawing.Point(441, 200);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(389, 30);
            this.comboBox1.TabIndex = 5;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(437, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "Managerial Role";
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.numericUni);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.numeric718);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.checkEsCalısmıyor);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.numeric06);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(31, 258);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 283);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Family Situation";
            // 
            // numericUni
            // 
            this.numericUni.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numericUni.Location = new System.Drawing.Point(6, 229);
            this.numericUni.Name = "numericUni";
            this.numericUni.Size = new System.Drawing.Size(120, 28);
            this.numericUni.TabIndex = 3;
            this.numericUni.ValueChanged += new System.EventHandler(this.numericCocuk_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(6, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(251, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "18 or above still student children";
            // 
            // numeric718
            // 
            this.numeric718.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numeric718.Location = new System.Drawing.Point(6, 164);
            this.numeric718.Name = "numeric718";
            this.numeric718.Size = new System.Drawing.Size(120, 28);
            this.numeric718.TabIndex = 2;
            this.numeric718.ValueChanged += new System.EventHandler(this.numericCocuk_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(6, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(179, 20);
            this.label7.TabIndex = 31;
            this.label7.Text = "7-18 years old children";
            // 
            // checkEsCalısmıyor
            // 
            this.checkEsCalısmıyor.AutoSize = true;
            this.checkEsCalısmıyor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkEsCalısmıyor.Location = new System.Drawing.Point(6, 26);
            this.checkEsCalısmıyor.Name = "checkEsCalısmıyor";
            this.checkEsCalısmıyor.Size = new System.Drawing.Size(267, 26);
            this.checkEsCalısmıyor.TabIndex = 0;
            this.checkEsCalısmıyor.Text = "Married, Spouse isn\'t working";
            this.checkEsCalısmıyor.UseVisualStyleBackColor = true;
            this.checkEsCalısmıyor.CheckedChanged += new System.EventHandler(this.checkEsCalısmıyor_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(2, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 20);
            this.label3.TabIndex = 29;
            this.label3.Text = "0-6 years old children";
            // 
            // numeric06
            // 
            this.numeric06.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.numeric06.Location = new System.Drawing.Point(6, 95);
            this.numeric06.Name = "numeric06";
            this.numeric06.Size = new System.Drawing.Size(120, 28);
            this.numeric06.TabIndex = 1;
            this.numeric06.ValueChanged += new System.EventHandler(this.numericCocuk_ValueChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Adana",
            "Adıyaman",
            "Afyonkarahisar",
            "Ağrı",
            "Aksaray",
            "Amasya",
            "Ankara",
            "Antalya",
            "Ardahan",
            "Artvin",
            "Aydın",
            "Balıkesir",
            "Bartın",
            "Batman",
            "Bayburt",
            "Bilecik",
            "Bingöl",
            "Bitlis",
            "Bolu",
            "Burdur",
            "Bursa",
            "Çanakkale",
            "Çankırı",
            "Çorum",
            "Denizli",
            "Diyarbakır",
            "Düzce",
            "Edirne",
            "Elazığ",
            "Erzincan",
            "Erzurum",
            "Eskişehir",
            "Gaziantep",
            "Giresun",
            "Gümüşhane",
            "Hakkâri",
            "Hatay",
            "Iğdır",
            "Isparta",
            "İstanbul",
            "İzmir",
            "Kahramanmaraş",
            "Karabük",
            "Karaman",
            "Kars",
            "Kastamonu",
            "Kayseri",
            "Kilis",
            "Kırıkkale",
            "Kırklareli",
            "Kırşehir",
            "Kocaeli",
            "Konya",
            "Kütahya",
            "Malatya",
            "Manisa",
            "Mardin",
            "Mersin",
            "Muğla",
            "Muş",
            "Nevşehir",
            "Niğde",
            "Ordu",
            "Osmaniye",
            "Rize",
            "Sakarya",
            "Samsun",
            "Şanlıurfa",
            "Siirt",
            "Sinop",
            "Sivas",
            "Şırnak",
            "Tekirdağ",
            "Tokat",
            "Trabzon",
            "Tunceli",
            "Uşak",
            "Van",
            "Yalova",
            "Yozgat",
            " Zonguldak"});
            this.comboBox2.Location = new System.Drawing.Point(29, 200);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(163, 30);
            this.comboBox2.TabIndex = 0;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // buttonDown
            // 
            this.buttonDown.Location = new System.Drawing.Point(391, 465);
            this.buttonDown.Name = "buttonDown";
            this.buttonDown.Size = new System.Drawing.Size(86, 23);
            this.buttonDown.TabIndex = 31;
            this.buttonDown.Text = "Download";
            this.buttonDown.UseVisualStyleBackColor = true;
            this.buttonDown.Visible = false;
            this.buttonDown.Click += new System.EventHandler(this.buttonDown_Click);
            // 
            // Salary_Calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 650);
            this.Controls.Add(this.buttonDown);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.numericDeneyim);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelUcret);
            this.Controls.Add(this.labelKatsayi);
            this.Controls.Add(this.labelBaz);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Salary_Calc";
            this.Text = "Salary_Calccs";
            this.Load += new System.EventHandler(this.Salary_Calc_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_quit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericDeneyim)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericDiger)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric718)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numeric06)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Labelc5;
        private System.Windows.Forms.PictureBox btn_quit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelBaz;
        private System.Windows.Forms.Label labelKatsayi;
        private System.Windows.Forms.Label labelUcret;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericDeneyim;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numericDiger;
        private System.Windows.Forms.RadioButton radioMez;
        private System.Windows.Forms.RadioButton radioBelgIng;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioIngYok;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkEsCalısmıyor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numeric06;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numeric718;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUni;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button buttonDown;
    }
}