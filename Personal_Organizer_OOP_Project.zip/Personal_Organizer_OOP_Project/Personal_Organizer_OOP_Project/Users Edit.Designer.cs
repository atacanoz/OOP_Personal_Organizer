﻿namespace Personal_Organizer_OOP_Project
{
    partial class Users_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_apply = new System.Windows.Forms.Button();
            this.btn_quit = new System.Windows.Forms.Button();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.txt_eMail = new System.Windows.Forms.TextBox();
            this.txt_adresses = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_phoneNumber = new System.Windows.Forms.TextBox();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.txt_surname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbBox_userType = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_changePhoto = new System.Windows.Forms.Button();
            this.uploadedPhoto = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.uploadedPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGreen;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(829, 81);
            this.panel1.TabIndex = 0;
            // 
            // btn_apply
            // 
            this.btn_apply.BackColor = System.Drawing.Color.DarkGreen;
            this.btn_apply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_apply.ForeColor = System.Drawing.Color.White;
            this.btn_apply.Location = new System.Drawing.Point(468, 411);
            this.btn_apply.Name = "btn_apply";
            this.btn_apply.Size = new System.Drawing.Size(148, 60);
            this.btn_apply.TabIndex = 0;
            this.btn_apply.Text = "Apply";
            this.btn_apply.UseVisualStyleBackColor = false;
            this.btn_apply.Click += new System.EventHandler(this.btn_apply_Click);
            // 
            // btn_quit
            // 
            this.btn_quit.BackColor = System.Drawing.Color.Red;
            this.btn_quit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_quit.ForeColor = System.Drawing.Color.White;
            this.btn_quit.Location = new System.Drawing.Point(644, 411);
            this.btn_quit.Name = "btn_quit";
            this.btn_quit.Size = new System.Drawing.Size(148, 60);
            this.btn_quit.TabIndex = 1;
            this.btn_quit.Text = "Cancel";
            this.btn_quit.UseVisualStyleBackColor = false;
            this.btn_quit.Click += new System.EventHandler(this.btn_quit_Click);
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(430, 354);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(355, 22);
            this.txtPass.TabIndex = 41;
            this.txtPass.Enter += new System.EventHandler(this.textBoxEnter);
            this.txtPass.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // txt_eMail
            // 
            this.txt_eMail.Location = new System.Drawing.Point(427, 257);
            this.txt_eMail.Name = "txt_eMail";
            this.txt_eMail.Size = new System.Drawing.Size(355, 22);
            this.txt_eMail.TabIndex = 40;
            this.txt_eMail.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_eMail.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // txt_adresses
            // 
            this.txt_adresses.Location = new System.Drawing.Point(426, 306);
            this.txt_adresses.Name = "txt_adresses";
            this.txt_adresses.Size = new System.Drawing.Size(355, 22);
            this.txt_adresses.TabIndex = 39;
            this.txt_adresses.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_adresses.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(429, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 20);
            this.label7.TabIndex = 38;
            this.label7.Text = "Password:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(426, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "E-mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(426, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 20);
            this.label5.TabIndex = 36;
            this.label5.Text = "Adresses:";
            // 
            // txt_phoneNumber
            // 
            this.txt_phoneNumber.Location = new System.Drawing.Point(12, 354);
            this.txt_phoneNumber.Name = "txt_phoneNumber";
            this.txt_phoneNumber.Size = new System.Drawing.Size(355, 22);
            this.txt_phoneNumber.TabIndex = 35;
            this.txt_phoneNumber.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_phoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_phoneNumber_KeyPress);
            this.txt_phoneNumber.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // txt_username
            // 
            this.txt_username.Location = new System.Drawing.Point(12, 305);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(355, 22);
            this.txt_username.TabIndex = 34;
            this.txt_username.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_username_KeyPress);
            this.txt_username.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // txt_surname
            // 
            this.txt_surname.Location = new System.Drawing.Point(12, 256);
            this.txt_surname.Name = "txt_surname";
            this.txt_surname.Size = new System.Drawing.Size(355, 22);
            this.txt_surname.TabIndex = 33;
            this.txt_surname.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_surname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_surname_KeyPress);
            this.txt_surname.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(12, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 32;
            this.label4.Text = "Phone Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(12, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 31;
            this.label3.Text = "User Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.TabIndex = 30;
            this.label2.Text = "Surname:";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(12, 207);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(355, 22);
            this.txt_name.TabIndex = 29;
            this.txt_name.Enter += new System.EventHandler(this.textBoxEnter);
            this.txt_name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_name_KeyPress);
            this.txt_name.Leave += new System.EventHandler(this.textBoxLeave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "Name:";
            // 
            // cmbBox_userType
            // 
            this.cmbBox_userType.FormattingEnabled = true;
            this.cmbBox_userType.Items.AddRange(new object[] {
            "admin",
            "user",
            "part-time user"});
            this.cmbBox_userType.Location = new System.Drawing.Point(12, 121);
            this.cmbBox_userType.Name = "cmbBox_userType";
            this.cmbBox_userType.Size = new System.Drawing.Size(121, 24);
            this.cmbBox_userType.TabIndex = 42;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(12, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 43;
            this.label8.Text = "User Type:";
            // 
            // btn_changePhoto
            // 
            this.btn_changePhoto.BackColor = System.Drawing.Color.Orange;
            this.btn_changePhoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_changePhoto.ForeColor = System.Drawing.Color.Black;
            this.btn_changePhoto.Location = new System.Drawing.Point(709, 142);
            this.btn_changePhoto.Name = "btn_changePhoto";
            this.btn_changePhoto.Size = new System.Drawing.Size(96, 40);
            this.btn_changePhoto.TabIndex = 45;
            this.btn_changePhoto.Text = "Upload";
            this.btn_changePhoto.UseVisualStyleBackColor = false;
            this.btn_changePhoto.Click += new System.EventHandler(this.btn_changePhoto_Click);
            // 
            // uploadedPhoto
            // 
            this.uploadedPhoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.uploadedPhoto.Location = new System.Drawing.Point(538, 87);
            this.uploadedPhoto.Name = "uploadedPhoto";
            this.uploadedPhoto.Size = new System.Drawing.Size(151, 142);
            this.uploadedPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.uploadedPhoto.TabIndex = 44;
            this.uploadedPhoto.TabStop = false;
            // 
            // Users_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 483);
            this.Controls.Add(this.btn_changePhoto);
            this.Controls.Add(this.uploadedPhoto);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbBox_userType);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.txt_eMail);
            this.Controls.Add(this.txt_adresses);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_phoneNumber);
            this.Controls.Add(this.txt_username);
            this.Controls.Add(this.txt_surname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_quit);
            this.Controls.Add(this.btn_apply);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Users_Edit";
            this.Text = "Users_Edit";
            this.Load += new System.EventHandler(this.Users_Edit_Load);
            this.Leave += new System.EventHandler(this.textBoxLeave);
            ((System.ComponentModel.ISupportInitialize)(this.uploadedPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_apply;
        private System.Windows.Forms.Button btn_quit;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txt_eMail;
        private System.Windows.Forms.TextBox txt_adresses;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_phoneNumber;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.TextBox txt_surname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBox_userType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox uploadedPhoto;
        private System.Windows.Forms.Button btn_changePhoto;
    }
}